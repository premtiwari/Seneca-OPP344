#include <iostream>
#include <iomanip>
#include <exception>
#include <string>
#include <type_traits>
#include <forward_list>
#include <fstream>
#include "Filesystem.h"
#include "Filesystem.h"
#include "Directory.h"
#include "Directory.h"
#include "File.h"
#include "File.h"
#include "Flags.h"
#include <sstream>  

using namespace std;
namespace sdds {




   Filesystem::Filesystem(string fileName, string rootDirectoryName) {


		ifstream file;
		file.open(fileName);

		if (file.is_open()) {
 
         m_root = new Directory(rootDirectoryName);
			m_current = m_root;


			while (!file.eof()) {

            string line;
            // std::stringstream ss;
             getline(file, line);
            // ss.str(line);
            
            string dir="",dir2="",file_name="",content="";
           // ss >> dir ;

           // cout<< dir << "\n";

           vector<string> DIR;

        
            int end=0;
            for(long unsigned int i=0; i< line.length(); i++)
            {  

               m_current = m_root;

               if( line[i] =='/' )
               {
                  dir+= line[i];
                  end=i+1;

                  DIR.push_back(dir);

                  dir="";
               
               }
               else 
               {
                  dir+=line[i];
               }

               //    string new_line="";
               //    for(int j=i+1; j < line.length(); j++)
               //    {
               //       new_line += line[j];
               //    }

               //    std::stringstream ss;
               //    ss.str(new_line);

               //    ss >> file_name;

               //    char ch;

               //    ss>>ch;

               //    getline(ss,content);

               //    break;
               // }
               // else if(line[i] =='|')
               // {
               //    std::stringstream ss;
               //    ss.str(line);

               //    ss >> file_name;

               //    char ch;
               //    ss>>ch;
               //    getline(ss,content);
               //    dir="";
               //    break;
               // }
               // else 
               // {
               //    dir+= line[i];
               // }

            }


           
            for(long unsigned int i=end; i< line.length(); i++)
            {       
               if(line[i]=='|')
               {  bool f=false;
                  for( long unsigned int j=i+1; j< line.length() ;j++) 
                  {
                        if( line[j]!=' ' ) f=true;
                        if( f ) 
                          {   
                        
                              content += line[j];
                          }
                  }
                  f=true;
                  int spacecount=0;
                  for( long unsigned int j=line.length() -1 ; j>0 ;j--) 
                  {
                        if( line[j]!=' ' ) f=false;
                        if( f ) 
                          {   spacecount++;
                             
                          }
                  }

                  string temp="";
                  for( long unsigned int j= 0 ; j < content.length() - spacecount ;j++) 
                  {
                        temp += content[j];
                  }
                  content=temp;

                 // content.erase(remove(content.begin() - spacecount , content.end(), ' '), content.end());

                 // content.erase(remove(content.end() - spacecount , content.end(), ' '), content.end());
                  
                  break;
               }
               else if( line[i]!=' ' )
               {
                  file_name+= line[i];
               }
            }   
           // cout <<"="<< file_name <<"="<<content<<"=\n";
           // cout<<"==";
            vector<string> DIR2;
            for( auto s : DIR ) 
            {
         
               std::stringstream ss;
               ss.str(s);
               ss >> dir;
               //cout<< dir<<"-";
               DIR2.push_back(dir);



            }
            //cout<<"---";
               std::stringstream ss;
               ss.str(file_name);
               ss >> file_name;

               //cout <<"="<<content<<"=\n";
             //  ss.str(content);
             //  ss >> content;
            //   getline(ss,line);
             //  content += line;
            //    cout<< file_name<<"--";
             //  cout <<"="<< file_name <<"="<<content<<"=\n";



					// Loop in tokens
               bool isDirectory = false;
					for (auto token : DIR2) {
		
						if( token[token.length()-1] == '/' ) isDirectory = true;
                  else isDirectory = false;

   
						if (m_current->find(token) != nullptr) { 

                     
					
							if (isDirectory) {
								m_current = dynamic_cast<Directory*>(m_current->find(token));
                        //cout<<"m_c="<<m_current->path()<<"--"<<m_current->name()<<"=";
							}
						}
						else if(isDirectory){
							
								m_current->operator+=(new Directory(token));

								m_current = dynamic_cast<Directory*>(m_current->find(token));
							
						}
					}

               if( file_name.length()!=0)
               m_current->operator+=(new File(file_name, content));





            //cout<<dir<< " "<< file_name<< " "<<content<<"\n";


            // if(flag)
            // {
            //    flag=false;

            //    sdds::File* _file = new sdds::File( file_name, content);
            //    m_root 

            // }


//======================================================




         //    if( dir[dir.length()-1] == '/' && file_name.length() !=0 )
         //    {  

         //      if( m_root->find(dir) )
         //      {
         //          Resource *D = m_root->find(dir);
         //          sdds::File* _file = new sdds::File( file_name, content);
         //          *D += _file;
         //      }
         //      else
         //      {
         //       Directory *D = new sdds::Directory(dir);
         //       sdds::File* _file = new sdds::File( file_name, content);
         //       *D += _file;
         //       *m_root += D;

         //      }


         //    }

         //    if(file_name.length() !=0  && dir.length() == 0 )
         //    {
         //       sdds::File* _file = new sdds::File( file_name, content);
         //       *m_root += _file;
         //    }
         //    else 
         //    {
         //      Directory *D = new sdds::Directory(dir);
         //      //sdds::File* _file = new sdds::File( file_name, content);
         //     //*m_current += _file;
         //      *m_root += D;

      
         //    }


            



			// }



       m_current = m_root;
         
         }
			
		}
      else 
      {
         throw std::invalid_argument("File cannot be opened.");
      }

		



      // if (m_current->type()==NodeType::DIR) {
      //    cout << m_root->path() << endl;
      // } else {
      //    cout << m_current->path() << " | " << endl;
      // }


   }
//    Filesystem::Filesystem(Filesystem&& F) {
//       operator=(move(F));
//    }
//    Filesystem& Filesystem::operator=(Filesystem&& F) {
//       if (this != &F) {
//          delete[] m_current;
//          delete[] m_root;
//          m_current = F.m_current;
//          F.m_current = nullptr;
//          m_root = F.m_root;
//          F.m_root = nullptr;
//       }
//       return *this;
//    }
   Filesystem& Filesystem::operator+=(Resource* R) {
      if (R) {

      }
      return *this;
   }
   Directory* Filesystem::change_directory(const std::string& dir) {
      if (!dir[0]) {
         return m_root;
      } else {
        // cout<<dir<<"\n";
         if (m_root->find(dir)) {
  
            m_current = dynamic_cast<sdds::Directory*>( m_root->find(dir));
            return m_current;

         } else {
            throw invalid_argument("Cannot change directory! DIR_NAME not found!");
         }
      }

      return m_current;
   }
   Directory* Filesystem::get_current_directory() const {
      return m_current;
   }
   Filesystem::~Filesystem() {
      delete m_current;
      delete m_root;
   }


   
}