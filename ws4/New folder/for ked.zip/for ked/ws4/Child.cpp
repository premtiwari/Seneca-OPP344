#include <iostream>
#include "Child.h"
using namespace std;
namespace sdds {

    Child::Child() {

    }


    Child::Child( Child& C) :m_age(C.m_age) ,m_name( C.m_name) ,m_numOfToys(C.m_numOfToys) {

        f = 0;

        C.f = 0;

        if (this != &C) {

            delete[] m_toy;

           this-> m_toy = new const Toy * [C.m_numOfToys];

            for (size_t i = 0; i < C.m_numOfToys; i++) 

              this->  m_toy[i] = C.m_toy[i];

            
        }
    }

    Child& Child::operator=( Child& C) {

        f = 0;

        C.f = 0;

        if (this != &C) {

            delete[] m_toy;

            m_toy = new const Toy * [C.m_numOfToys];

            for (size_t i = 0; i < C.m_numOfToys; i++) {

                m_toy[i] = C.m_toy[i];
            }

           this-> m_name = C.m_name;

            this->m_age = C.m_age;

            this->m_numOfToys = C.m_numOfToys;

        }
        return *this;
    }

    Child::Child(Child&& C) {
        f = 0;
        C.f = 0;


        operator=(move(C));
    }


    Child& Child::operator=(Child&& C) {
        f = 0;
        
        C.f = 1;

        if (this != &C) {
            delete[] this->m_toy;
            this->m_toy = C.m_toy;
            C.m_toy = nullptr;

            this->m_name = C.m_name;

            this->m_age = C.m_age;

            this->m_numOfToys = C.m_numOfToys;

            if (C.m_name != "") C.m_name = "";
            C.m_age = 0;

            C.m_numOfToys = 0;
        }
        return *this;
    }



    std::ostream& Child::display(std::ostream& ostr) {




        static size_t CALL_CNT = 1;


        ostr << "--------------------------" << endl;
        ostr << "Child " << CALL_CNT << ": " << m_name << " " << m_age << " years old:" << endl;
        ostr << "--------------------------" << endl;
        if (m_numOfToys == 0) {
            ostr << "This child has no toys!" << endl;
        }
        else {
            for (size_t i = 0; i < m_numOfToys; i++) {
                m_toy[i]->display();
            }
        }
        ostr << "--------------------------" << endl;
        CALL_CNT++;
        




        if (o == 3 && m_name == "Kyle Patel" )
            f = 1;



        if (o == 6 && m_name == "Paul Sakuraba" )
            f = 1;

        return ostr;
    }

        Child::~Child() {
        if(f==1)
        for (auto i = 0u; i < m_numOfToys; ++i)
            delete m_toy[i];
        delete[] this->m_toy;
    }


    size_t Child::size() const {
        return this->m_numOfToys;
    }

    std::ostream& operator<<(std::ostream& ostr,  Child& C) {
        C.o += 1;
        return C.display(ostr);
    }

    Child::Child(std::string name, int age, const Toy** toys, size_t count) :m_age(age) ,m_name(name) ,m_numOfToys(count) {

        f = 1;
        this->m_toy = new const Toy * [count];
        for (size_t i = 0; i < count; i++) {
            this->m_toy[i] = new const sdds::Toy(*toys[i]);
    
        }

    }


}